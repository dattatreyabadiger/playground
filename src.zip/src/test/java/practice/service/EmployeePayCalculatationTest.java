package practice.service;

import org.junit.jupiter.api.Test;
import practice.dto.ContractTypeEnum;
import practice.dto.Employee;
import practice.dto.Shift;
import practice.dto.SkillEnum;
import practice.repository.ContractPayRepository;
import practice.repository.SkillPayRepository;

import java.util.ArrayList;
import java.util.List;


class EmployeePayCalculatationTest {


    private final SkillPayRepository skillPayRepository = new SkillPayRepository();
    private final ContractPayRepository contractPayRepository = new ContractPayRepository();
    private final EmployeePayCalculation employeePayCalculationService = new EmployeePayCalculation(skillPayRepository, contractPayRepository);

    @Test
    void testCalculatePay() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, ContractTypeEnum.PERMANENT, List.of(new Shift(1, SkillEnum.BAKERY, 6, 1))));
        employeePayCalculationService.calculatePay(employees);
        System.out.println(employees);
    }
}
