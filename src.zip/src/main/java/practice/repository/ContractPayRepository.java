package practice.repository;

import practice.dto.ContractTypeEnum;
import practice.dto.SkillEnum;

import java.math.BigDecimal;
import java.util.Map;

import static practice.dto.ContractTypeEnum.AGENCY;
import static practice.dto.ContractTypeEnum.PERMANENT;
import static practice.dto.ContractTypeEnum.ZERO_HOURS;

public class ContractPayRepository {

    private final Map<ContractTypeEnum, BigDecimal> contractTypeCalculationMap =
            Map.of(PERMANENT, BigDecimal.valueOf(12.5),
                   AGENCY, BigDecimal.valueOf(12.5),
                   ZERO_HOURS, BigDecimal.valueOf(13));

    public BigDecimal getPayForContract(ContractTypeEnum skill) {
        return contractTypeCalculationMap.get(skill);
    }
}
