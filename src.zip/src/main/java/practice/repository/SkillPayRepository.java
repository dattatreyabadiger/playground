package practice.repository;

import practice.dto.SkillEnum;

import java.math.BigDecimal;
import java.util.Map;

import static practice.dto.SkillEnum.BAKERY;
import static practice.dto.SkillEnum.CHECKOUT_CASHIER;
import static practice.dto.SkillEnum.CLEANING;
import static practice.dto.SkillEnum.CUSTOMER_SERVICE;
import static practice.dto.SkillEnum.DELIVERY_DRIVER;
import static practice.dto.SkillEnum.SECURITY;
import static practice.dto.SkillEnum.SHIFT_LEADER;

public class SkillPayRepository {

    private final Map<SkillEnum, BigDecimal> skillPayCalculationMap =
            Map.of(BAKERY, BigDecimal.valueOf(2),
                   CHECKOUT_CASHIER, BigDecimal.valueOf(1.2),
                   CUSTOMER_SERVICE, BigDecimal.valueOf(1.3),
                   SHIFT_LEADER, BigDecimal.valueOf(3),
                   SECURITY, BigDecimal.valueOf(1),
                   CLEANING, BigDecimal.valueOf(1),
                   DELIVERY_DRIVER, BigDecimal.valueOf(2));

    public BigDecimal getPayForSkill(SkillEnum skill) {
        return skillPayCalculationMap.get(skill);
    }
}
