package practice.dto;

import lombok.Getter;

import java.util.List;

@Getter
public class Employee {

    private int id;
    private ContractTypeEnum contractType;
    private List<Shift> shifts;

    public Employee(int id,
                    ContractTypeEnum contractType,
                    List<Shift> shifts) {
        this.id = id;
        this.contractType = contractType;
        this.shifts = shifts;
    }
}
