package practice.dto;

public enum SkillEnum {

    BAKERY,
    CHECKOUT_CASHIER,
    CUSTOMER_SERVICE,
    SHIFT_LEADER,
    SECURITY,
    CLEANING,
    DELIVERY_DRIVER

}
