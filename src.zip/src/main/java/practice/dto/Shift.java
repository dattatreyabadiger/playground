package practice.dto;

import lombok.Getter;

@Getter
public class Shift {

    private int id;
    private SkillEnum skill;
    private int totalDuration;
    private int breakDuration;

    public Shift(int id,
                 SkillEnum skill,
                 int totalDuration,
                 int breakDuration) {
        this.id = id;
        this.skill = skill;
        this.totalDuration = totalDuration;
        this.breakDuration = breakDuration;
    }
}
