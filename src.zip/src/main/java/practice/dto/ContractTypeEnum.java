package practice.dto;

public enum ContractTypeEnum {
    PERMANENT,
    AGENCY,
    ZERO_HOURS;
}
