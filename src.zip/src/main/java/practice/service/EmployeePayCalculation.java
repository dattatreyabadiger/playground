package practice.service;

import lombok.AllArgsConstructor;
import practice.dto.Employee;
import practice.dto.Shift;
import practice.repository.ContractPayRepository;
import practice.repository.SkillPayRepository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
public class EmployeePayCalculation {

    private final SkillPayRepository skillPayRepository;
    private final ContractPayRepository contractPayRepository;

    public Map<Integer, BigDecimal> calculatePay(List<Employee> employees) {
        Map<Integer, BigDecimal> employeeIdToPayMap = new HashMap<>();
        employees.forEach(employee -> {
            List<Shift> shifts = employee.getShifts();

            BigDecimal totalPay = BigDecimal.ZERO;
            totalPay.add(contractPayRepository.getPayForContract(employee.getContractType()));
            for (Shift shift : shifts) {
                BigDecimal payForSkillPerHour = skillPayRepository.getPayForSkill(shift.getSkill());
                BigDecimal workDuration = BigDecimal.valueOf(shift.getTotalDuration() - shift.getBreakDuration());
                totalPay = totalPay.add(payForSkillPerHour.multiply(workDuration));
            }
            employeeIdToPayMap.put(employee.getId(), totalPay);
        });
        return employeeIdToPayMap;
    }
}
